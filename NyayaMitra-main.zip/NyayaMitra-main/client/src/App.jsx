import { Navigate, NavLink, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import AuthForm from './pages/AuthForm.jsx'
import Home from './pages/Home.jsx'
import Chat from './pages/Chat.jsx'
import Templates from './pages/Templates.jsx'
import EmergencyContacts from './pages/EmergencyContacts.jsx'
import SOSButton from './components/SOSButton.jsx'
import { useAuth } from './context/AuthContext.jsx'

function ProtectedRoute() {
  const { user, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-stone-100 p-6">
        <p className="text-lg font-medium text-slate-700">Loading NyayaMitra...</p>
      </main>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace state={{ from: { pathname: location.pathname } }} />
  }

  return <Outlet />
}

function App() {
  const { user, loading, signOut } = useAuth()

  if (loading) return <p className="p-8 text-slate-700">Loading...</p>

  return (
    <div className="min-h-screen bg-stone-100 text-slate-800">
      {user && (
        <>
          <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur-sm">
            <nav className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
              <NavLink to="/" className="flex items-center" aria-label="NyayaMitra home">
                <img
                  src="/nyayamitra-full-logo-with-text.png"
                  alt="NyayaMitra"
                  className="h-10 w-auto sm:h-12"
                />
              </NavLink>

              <div className="flex items-center gap-2 sm:gap-3">
                <NavLink
                  to="/chat"
                  className={({ isActive }) =>
                    `rounded-full px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`
                  }
                >
                  Chat
                </NavLink>
                <NavLink
                  to="/templates"
                  className={({ isActive }) =>
                    `rounded-full px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`
                  }
                >
                  Templates
                </NavLink>
                <NavLink
                  to="/emergency-contacts"
                  className={({ isActive }) =>
                    `rounded-full px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`
                  }
                >
                  Emergency Contacts
                </NavLink>
                <button
                  type="button"
                  onClick={signOut}
                  className="rounded-full bg-slate-900 px-3 py-2 text-sm font-medium text-white transition hover:bg-slate-700"
                >
                  Logout
                </button>
              </div>
            </nav>
          </header>

          <div className="fixed bottom-6 right-6 z-50">
            <SOSButton />
          </div>
        </>
      )}

      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" replace /> : <AuthForm mode="login" />} />
        <Route path="/signup" element={user ? <Navigate to="/" replace /> : <AuthForm mode="signup" />} />

        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<Home />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/templates" element={<Templates />} />
          <Route path="/emergency-contacts" element={<EmergencyContacts />} />
        </Route>

        <Route path="*" element={<Navigate to={user ? '/' : '/login'} replace />} />
      </Routes>
    </div>
  )
}

export default App
