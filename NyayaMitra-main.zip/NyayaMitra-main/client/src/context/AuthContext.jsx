import { createContext, useContext, useEffect, useState } from 'react'
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
} from 'firebase/auth'
import { auth } from '../firebase.js'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    return onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser)
      if (nextUser) {
        localStorage.setItem('firebaseIdToken', await nextUser.getIdToken())
      } else {
        localStorage.removeItem('firebaseIdToken')
      }
      setLoading(false)
    })
  }, [])

  async function signUp(email, password) {
    const result = await createUserWithEmailAndPassword(auth, email, password)
    localStorage.setItem('firebaseIdToken', await result.user.getIdToken())
    return result.user
  }

  async function signIn(email, password) {
    const result = await signInWithEmailAndPassword(auth, email, password)
    localStorage.setItem('firebaseIdToken', await result.user.getIdToken())
    return result.user
  }

  async function signOut() {
    await firebaseSignOut(auth)
    localStorage.removeItem('firebaseIdToken')
  }

  return (
    <AuthContext.Provider value={{ user, loading, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}