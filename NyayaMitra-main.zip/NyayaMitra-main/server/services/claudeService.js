import Groq from 'groq-sdk'

const categories = [
  'cyber_fraud',
  'harassment',
  'property',
  'employment',
  'domestic',
  'consumer',
  'other',
]
const model = 'openai/gpt-oss-20b'

let client

function getClient() {
  if (!process.env.GROQ_API_KEY) {
    throw new Error('GROQ_API_KEY is not configured')
  }

  client ??= new Groq({ apiKey: process.env.GROQ_API_KEY })
  return client
}

function getText(response) {
  return response.choices?.[0]?.message?.content?.trim() || ''
}

function parseCategory(rawText) {
  const normalizedText = rawText.toLowerCase()
  const jsonStart = normalizedText.indexOf('{')
  const jsonEnd = normalizedText.lastIndexOf('}')

  if (jsonStart !== -1 && jsonEnd > jsonStart) {
    try {
      const parsed = JSON.parse(normalizedText.slice(jsonStart, jsonEnd + 1))
      if (typeof parsed.category === 'string') {
        const parsedCategory = categories.find((category) =>
          parsed.category.toLowerCase().includes(category),
        )
        if (parsedCategory) return parsedCategory
      }
    } catch {
      // Fall through to substring matching for imperfect model output.
    }
  }

  return categories.find((category) => normalizedText.includes(category)) || 'other'
}

export async function processMessage(message, getLegalContexts) {
  const classificationRequest = {
    model,
    max_tokens: 300,
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: `Classify the user's legal query into exactly one category: ${categories.join(', ')}. Respond with ONLY a JSON object like {"category":"cyber_fraud"} — no other text.`,
      },
      { role: 'user', content: message },
    ],
  }
  const classificationResponse = await getClient().chat.completions.create(
    classificationRequest,
    { signal: AbortSignal.timeout(20000) },
  )

  const rawText = getText(classificationResponse)
  const category = parseCategory(rawText)
  const legalContexts = await getLegalContexts(category)
  const context = legalContexts.length
    ? JSON.stringify(legalContexts)
    : 'No matching legal context was found.'

  const answerResponse = await getClient().chat.completions.create(
    {
      model,
      max_tokens: 1024,
      messages: [
        {
          role: 'system',
          content: 'Answer the user in plain language about Indian law and practical next steps. ONLY use the legal context provided below. Do not invent, infer, or add legal citations, sections, deadlines, or procedures that are not present in the context. State clearly when the context is insufficient. Do not claim to be a lawyer.\n\nProvided legal context:\n' + context,
        },
        { role: 'user', content: message },
      ],
    },
    { signal: AbortSignal.timeout(20000) },
  )

  return { category, answer: getText(answerResponse) }
}